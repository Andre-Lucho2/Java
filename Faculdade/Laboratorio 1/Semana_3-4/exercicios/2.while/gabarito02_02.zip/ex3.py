num1 = int(input("Digite o primeiro valor:"))
num2 = int(input("Digite o segundo valor:"))

if(num1 < num2):

  cont = num1+1

  while(cont < num2):
    print(cont)
    cont += 1
else:
  print("Erro: primeiro valor deve ser menor do que o segundo")