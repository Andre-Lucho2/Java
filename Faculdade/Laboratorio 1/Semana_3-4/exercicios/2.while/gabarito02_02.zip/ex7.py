user = input("Digite seu usuário:")
password = input("Digite sua senha:")

while(user != "USER10" or password != "PASSWORD1234"):
  print("Usuário e/ou senha inválidos")
  user = input("Digite seu usuário:")
  password = input("Digite sua senha:")
  
print("Login efetuado com sucesso!")
  
  
  