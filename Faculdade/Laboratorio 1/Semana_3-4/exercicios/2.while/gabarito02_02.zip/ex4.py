num1 = int(input("Digite o primeiro valor:"))
num2 = int(input("Digite o segundo valor:"))

if(num1 < num2):

  cont = num1 #ou num1+1 se não quiser incluir o valor de num1

  while(cont <= num2): #ou cont < num2 se não quiser incluir o valor de num2
    print(cont)
    cont += 1
else:
  
  cont = num2
  
  while(cont <= num1):
    print(cont)
    cont += 1
  
  
  
  
  
  
  
  