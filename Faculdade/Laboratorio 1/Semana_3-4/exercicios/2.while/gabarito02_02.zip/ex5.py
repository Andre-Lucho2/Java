cont = 1
soma = 0

while(cont <= 1000):
  soma += cont
  cont += 1
  
print(soma)
  
  
  
  
  
  
  
  