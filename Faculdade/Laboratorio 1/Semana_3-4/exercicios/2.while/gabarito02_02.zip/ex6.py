num = int(input("Digite valores positivos e pares:"))

soma = 0

while(num > 0 and num % 2 == 0):
  soma += num
  num = int(input("Digite valores positivos e pares:"))
  
print(soma)
  
  
  
  
  