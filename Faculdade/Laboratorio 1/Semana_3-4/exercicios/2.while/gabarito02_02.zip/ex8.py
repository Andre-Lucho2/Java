tentativas = 0
acertou = False
usuario = input("Digite seu usu�rio: ")
senha = input("Digite sua senha: ")

while usuario != "USER10" or senha != "PASSWORD1234":
  print("Usu�rio ou senha inv�lidos!")
  usuario = input("Digite seu usu�rio: ")
  senha = input("Digite sua senha: ")
  tentativas += 1
  if usuario == "USER10" and senha == "PASSWORD1234":
    acertou = True
  if tentativas == 2:
    break

if not(acertou) and tentativas > 0:
  print("N�MERO M�XIMO DE TENTATIVAS EXCEDIDO!")
else:
  print("LOGIN EFETUADO COM SUCESSO!")