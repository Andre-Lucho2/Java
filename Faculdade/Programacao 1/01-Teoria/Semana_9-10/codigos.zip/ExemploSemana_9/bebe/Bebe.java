package bebe;
import java.time.LocalDate;

public class Bebe extends Pessoa {
    private Medico medicoQueFezParto;
    private Mae mae;
    private Medicamento medicamento;
    private int quantidadeMedicamento;
    private LocalDate dataMedicamento;
    private String horarioMedicamento;

    public Bebe(String nome, String sobreNome, Medico medicoQueFezParto, Mae mae, LocalDate dataNascimento) {
        super(nome, sobreNome, dataNascimento, mae.getEndereco(), mae.getTelefone());
        this.medicoQueFezParto = medicoQueFezParto;
        this.mae = mae;
    }

    public void adicionarMedicamento(Medicamento medicamento, int quantidade, LocalDate data, String horario) {
        this.medicamento = medicamento;
        this.quantidadeMedicamento = quantidade;
        this.dataMedicamento = data;
        this.horarioMedicamento = horario;
    }

    @Override
    public String toString() {
        return "Bebe [nome=" + nome + ", dataNascimento=" + dataNascimento + ", endereco=" + endereco + ", telefone="
                + telefone + ", medicoQueFezParto=" + medicoQueFezParto + ", mae=" + mae + ", medicamento="
                + medicamento + ", quantidadeMedicamento=" + quantidadeMedicamento + ", dataMedicamento="
                + dataMedicamento + ", horarioMedicamento=" + horarioMedicamento + "]\n";
    }
}
