package bebe;

public enum UnidadeMedida {
    ML, MG, G;
}
