package bebe;
import java.time.LocalDate;

public class Mae extends Pessoa {
    public Mae(String nome, String sobreNome, LocalDate dataNascimento, String endereco, String telefone) {
        super(nome, sobreNome, dataNascimento, endereco, telefone);
    }

    @Override
    public String toString() {
        return "Mae [nome=" + nome + ", sobrenome=" + sobreNome + ", dataNascimento=" + dataNascimento + ", endereco="
                + endereco + ", telefone=" + telefone + "]\n";
    }
}

