package bebe;

public class Medicamento {
    protected String descricao;
    protected int quantidadeEstoque;
    protected UnidadeMedida unidadeMedida;

    public Medicamento(String descricao, int quantidadeEstoque, UnidadeMedida unidadeMedida) {
        this.descricao = descricao;
        this.quantidadeEstoque = quantidadeEstoque;
        this.unidadeMedida = unidadeMedida;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public int getQuantidadeEstoque() {
        return quantidadeEstoque;
    }

    public void setQuantidadeEstoque(int quantidadeEstoque) {
        this.quantidadeEstoque = quantidadeEstoque;
    }

    public UnidadeMedida getUnidadeMedida() {
        return unidadeMedida;
    }

    public void setUnidadeMedida(UnidadeMedida unidadeMedida) {
        this.unidadeMedida = unidadeMedida;
    }

    @Override
    public String toString() {
        return "Medicamento [descricao=" + descricao + ", quantidadeEstoque=" + quantidadeEstoque + ", unidadeMedida=" + unidadeMedida + "]";
    }
}
