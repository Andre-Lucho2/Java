package bebe;

import java.time.LocalDate;

public class Pessoa {
    protected String nome;
    protected String sobreNome;
    protected LocalDate dataNascimento;
    protected String endereco;
    protected String telefone;

    public Pessoa(String nome, String sobreNome, LocalDate dataNascimento, String endereco, String telefone) {
        this.nome = nome;
        this.sobreNome = sobreNome;
        this.dataNascimento = dataNascimento;
        this.endereco = endereco;
        this.telefone = telefone;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getsobreNome() {
        return sobreNome;
    }

    public void setsobreNome(String sobreNome) {
        this.sobreNome = sobreNome;
    }

    public LocalDate getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(LocalDate dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    @Override
    public String toString() {
        return "Pessoa [nome=" + nome + ", sobreNome=" + sobreNome + ", dataNascimento=" + dataNascimento + ", endereco=" + endereco + ", telefone="
                + telefone + "]\n";
    }
}
