package bebe;

import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {
        // Cria uma unidade de medida
        UnidadeMedida ml = UnidadeMedida.ML;

        // Cria um medicamento
        Medicamento tylenol = new Medicamento("Tylenol", 50, ml);

        // Cria um médico
        Medico medico = new Medico("José", "Silva", LocalDate.of(1970, 5, 10), "1234567", "Rua B, 456", "987654321");

        // Cria uma mãe
        Mae mae = new Mae("Maria", "Santos", LocalDate.of(1985, 8, 15), "Rua A, 123", "123456789");

        // Cria um bebê
        Bebe bebe = new Bebe("João", "Santos", medico, mae, LocalDate.of(2020, 1, 1));

        // Imprime informações do bebê
        System.out.println(bebe);

        // Adiciona o medicamento ao bebê
        bebe.adicionarMedicamento(tylenol, 2, LocalDate.of(2021, 1, 1), "08:00");

        // Imprime informações do bebê novamente
        System.out.println(bebe);
    }
}