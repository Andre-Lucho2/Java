package bebe;

import java.time.LocalDate;

public class Medico extends Pessoa {
    protected String CRM;

    public Medico(String nome, String sobreNome, LocalDate dataNascimento, String endereco, String telefone, String CRM) {
        super(nome, sobreNome, dataNascimento, endereco, telefone);
        this.CRM = CRM;
    }

    public String getCRM() {
        return CRM;
    }

    public void setCRM(String CRM) {
        this.CRM = CRM;
    }

    @Override
    public String toString() {
        return "Medico [" + super.toString() + ", CRM=" + CRM + "]\n";
    }
}

