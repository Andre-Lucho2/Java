package sobreescrita;

public class TesteSobrescrita {
    public static void main(String[] args) {
        Animal animal1 = new Animal();
        animal1.emitirSom(); // imprime "O animal está emitindo um som."

        Animal animal2 = new Cachorro();
        animal2.emitirSom(); // imprime "O cachorro está latindo!"

        Animal animal3 = new Gato();
        animal3.emitirSom(); // imprime "O gato está miando!"
    }
}
