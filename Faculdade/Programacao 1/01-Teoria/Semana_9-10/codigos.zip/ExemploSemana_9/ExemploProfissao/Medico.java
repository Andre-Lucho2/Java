package ExemploProfissao;

public class Medico extends Profissao {
    private String especialidade;

    public Medico(String nome, String descricao, String especialidade) {
        super(nome, descricao);
        this.especialidade = especialidade;
    }

    public String getEspecialidade() {
        return especialidade;
    }

    public void setEspecialidade(String especialidade) {
        this.especialidade = especialidade;
    }

    @Override
    public void exibirInformacoes() {
        super.exibirInformacoes();
        System.out.println("Especialidade: " + especialidade);
    }
}