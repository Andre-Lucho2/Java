package ExemploProfissao;

public class MainExemploProfissoes {
    public static void main(String[] args) {
        Profissao profissao1 = new Profissao("Professor", "Pessoa que ensina em uma escola ou universidade.");
        profissao1.exibirInformacoes();

        Medico medico1 = new Medico("Médico", "Pessoa que cuida da saúde de outras pessoas.", "Cardiologista");
        medico1.exibirInformacoes();

        Engenheiro engenheiro1 = new Engenheiro("Engenheiro", "Pessoa que projeta e constrói estruturas e sistemas.", "Civil");
        engenheiro1.exibirInformacoes();
    }
    
}
