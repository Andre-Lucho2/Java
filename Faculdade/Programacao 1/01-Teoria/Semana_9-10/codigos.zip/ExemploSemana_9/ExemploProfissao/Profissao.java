package ExemploProfissao;

public class Profissao{
    private String nome;
    private String descricao;

    public Profissao(String nome, String descricao) {
        this.nome = nome;
        this.descricao = descricao;
    }

    public String getNome() {
        return nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public void exibirInformacoes() {
        System.out.println("Profissão: " + nome);
        System.out.println("Descrição: " + descricao);
    }
}