package ExemploProfissao;

public class ExemploUpcastingDowncasting {
    public static void main(String[] args) {
        // Upcasting - objeto da subclasse é convertido para a superclasse
        Medico medico1 = new Medico("Médico", "Pessoa que cuida da saúde de outras pessoas.", "Cardiologista");
        Profissao profissao1 = medico1; // medico1 é uma Profissao

        profissao1.exibirInformacoes(); // chama o método exibirInformacoes da classe Profissao

        // Downcasting - objeto da superclasse é convertido para a subclasse
        Profissao profissao2 = new Engenheiro("Engenheiro", "Pessoa que projeta e constrói estruturas e sistemas.", "Civil");
        Engenheiro engenheiro1 = (Engenheiro) profissao2; // profissao2 é um Engenheiro

        engenheiro1.setDescricao("Pessoa que projeta e constrói estruturas e sistemas complexos."); // altera a descrição do engenheiro
        engenheiro1.exibirInformacoes(); // chama o método exibirInformacoes da classe Engenheiro
    }
}

/*
  criamos um objeto medico1 da classe Medico e fazemos um upcasting, convertendo-o para a classe Profissao. 
  Em seguida, chamamos o método exibirInformacoes no objeto profissao1, que agora é uma instância da classe Profissao. 
  Como a classe Profissao tem sua própria implementação do método exibirInformacoes, o método correto é chamado e a saída é:

Profissão: Médico
Descrição: Pessoa que cuida da saúde de outras pessoas.

 Em seguida, criamos um objeto profissao2 da classe Engenheiro e fazemos um downcasting, convertendo-o de volta para a classe Engenheiro. 
 Como o objeto profissao2 foi criado como um objeto Engenheiro, podemos convertê-lo de volta para essa classe sem perda de informações.  
 
 Alteramos a descrição do objeto engenheiro1 e chamamos o método exibirInformacoes, que agora é uma instância da classe Engenheiro. 
 Como a classe Engenheiro tem sua própria implementação do método exibirInformacoes, o método correto é chamado e a saída é:
    Profissão: Engenheiro
    Descrição: Pessoa que projeta e constrói estruturas e sistemas complexos.
    Área: Civil

Observe que, neste exemplo, o downcasting foi bem-sucedido porque o objeto profissao2 foi originalmente criado como um objeto Engenheiro. Se tentássemos fazer downcasting de um objeto Profissao que não foi criado como um objeto Engenheiro, o downcasting geraria uma exceção ClassCastException em tempo de execução. 
Por isso, é importante verificar cuidadosamente se uma conversão é válida antes de fazer downcasting.

 */