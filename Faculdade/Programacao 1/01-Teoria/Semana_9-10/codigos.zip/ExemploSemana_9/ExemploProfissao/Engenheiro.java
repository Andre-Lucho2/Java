package ExemploProfissao;

public class Engenheiro extends Profissao {
    private String area;

    public Engenheiro(String nome, String descricao, String area) {
        super(nome, descricao);
        this.area = area;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    @Override
    public void exibirInformacoes() {
        super.exibirInformacoes();
        System.out.println("Área: " + area);
    }
}
