public class Gato extends Animal {
    public void fazerBarulho(String som) {
        if (som.equals("miau")) {
            System.out.println("O gato está miando!");
        } else {
            System.out.println("Som inválido para gato!");
        }
    }
}