public class ExemploSobrecarga {
    public static void main(String[] args) {
        Cachorro cachorro = new Cachorro();
        cachorro.fazerBarulho("au");
        cachorro.fazerBarulho("miau");
        
        Gato gato = new Gato();
        gato.fazerBarulho("miau");
        gato.fazerBarulho("au");
    }
}