public class Cachorro extends Animal {
    public void fazerBarulho(String som) {
        if (som.equals("au")) {
            System.out.println("O cachorro está latindo!");
        } else {
            System.out.println("Som inválido para cachorro!");
        }
    }
}