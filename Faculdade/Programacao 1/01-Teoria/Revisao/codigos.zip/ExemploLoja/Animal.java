class Animal {
    // classe base Animal
}

class Cachorro extends Animal {
    // classe filha Cachorro
}

class Gato extends Animal {
    // classe filha Gato
}
