public class Main {
    public static void main(String[] args) {
        // Upcasting - Loja para Informatica
        Loja lojaInformatica = new Informatica(220, 4500.0, 6, 1500);

        if (lojaInformatica instanceof Informatica) {
            Informatica informaticaLoja = (Informatica) lojaInformatica;
            System.out.println("Objeto lojaInformatica é uma instância da classe Informatica");
            System.out.println(informaticaLoja.toString());
        }
        else {
            System.out.println("Objeto lojaInformatica não é uma instância da classe Informatica");
        }

        // Downcasting - Loja para Vestuario
        Loja lojaVestuario = new Vestuario(140, 2800.0, 7, 400);

        if (lojaVestuario instanceof Vestuario) {
            Vestuario vestuarioLoja = (Vestuario) lojaVestuario;
            System.out.println("Objeto lojaVestuario é uma instância da classe Vestuario");
            System.out.println(vestuarioLoja.toString());
        }
        else {
            System.out.println("Objeto lojaVestuario não é uma instância da classe Vestuario");
        }
    }
}

