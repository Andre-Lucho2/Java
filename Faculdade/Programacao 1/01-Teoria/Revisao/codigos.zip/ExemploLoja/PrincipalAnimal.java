public class PrincipalAnimal{
    public static void main(String[] args) {
        //Animal animal = new Animal();
        Animal animal = new Cachorro();

        if (animal instanceof Cachorro) {
            System.out.println("Objeto animal é uma instância da classe Cachorro");
        } else {
            System.out.println("Objeto animal não é uma instância da classe Cachorro");
        }
    }
}
