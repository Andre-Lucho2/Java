public class ArrayFor {
    public static void main(String[] args) {
        // Criando um array de objetos
        Integer[] numeros = new Integer[5];
        numeros[0] = 10;
        numeros[2] = 30;

        // Utilizando o for convencional para iterar sobre o array
        System.out.println("Iteração com for convencional:");
        for (int i = 0; i < numeros.length; i++) {
            if (numeros[i] == null) {
                System.out.println("Elemento " + i + " é nulo.");
            } else {
                System.out.println("Elemento " + i + ": " + numeros[i]);
            }
        }

        // Utilizando o for-each para iterar sobre o array
        System.out.println("\nIteração com for-each:");
        int index = 0;
        for (Integer numero : numeros) {
            if (numero == null) {
                System.out.println("Elemento " + index + " é nulo.");
            } else {
                System.out.println("Elemento " + index + ": " + numero);
            }
            index++;
        }
    }
}

