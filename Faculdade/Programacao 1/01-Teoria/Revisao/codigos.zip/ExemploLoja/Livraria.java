class Livraria extends Loja {
    private int quantidadeProdutos;

    public Livraria(int metrosQuadrados, double valor, int numeroLoja, int quantidadeProdutos) {
        super(metrosQuadrados, valor, numeroLoja);
        this.quantidadeProdutos = quantidadeProdutos;
    }

    public int getQuantidadeProdutos() {
        return quantidadeProdutos;
    }

    @Override
    public String toString() {
        return "Livraria [metrosQuadrados=" + getMetrosQuadrados() + ", valor=" + getValor() +
                ", numeroLoja=" + getNumeroLoja() + ", quantidadeProdutos=" + quantidadeProdutos + "]";
    }
}
