public class Principal {
    public static void main(String[] args) {
         // Instanciando a classe Loja
        Loja loja = new Loja(100, 2000.0, 1);
        System.out.println(loja.toString());

        // Instanciando a classe Livraria
        Livraria livraria = new Livraria(150, 3000.0, 2, 500);
        System.out.println(livraria.toString());

        // Instanciando a classe Informatica
        Informatica informatica = new Informatica(200, 4000.0, 3, 1000);
        System.out.println(informatica.toString());

        // Instanciando a classe Vestuario
        Vestuario vestuario = new Vestuario(120, 2500.0, 4, 300);
        System.out.println(vestuario.toString());

        // Upcasting - Loja para Livraria
        Loja lojaLivraria = new Livraria(180, 3500.0, 5, 800);
        System.out.println(lojaLivraria.toString());

        // Upcasting - Loja para Informatica
        Loja lojaInformatica = new Informatica(220, 4500.0, 6, 1500);
        System.out.println(lojaInformatica.toString());

        // Upcasting - Loja para Vestuario
        Loja lojaVestuario = new Vestuario(140, 2800.0, 7, 400);
        System.out.println(lojaVestuario.toString());

        // Downcasting - Livraria para Loja
        Livraria livrariaLoja = (Livraria) lojaLivraria;
        System.out.println(livrariaLoja.toString());

        // Downcasting - Informatica para Loja
        Informatica informaticaLoja = (Informatica) lojaInformatica;
        System.out.println(informaticaLoja.toString());

        // Downcasting - Vestuario para Loja
        Vestuario vestuarioLoja = (Vestuario) lojaVestuario;
        System.out.println(vestuarioLoja.toString());
    }
}

/*
Downcasting - Vestuario para Loja
O código faz a conversão de uma referência da classe pai Loja para a classe filha Vestuario por meio do downcasting e, 
em seguida, imprime os dados do objeto vestuarioLoja.

Vestuario vestuarioLoja = (Vestuario) lojaVestuario;
Downcasting, converte uma referência da classe pai (Loja) para a classe filha (Vestuario). 
Para fazer isso, utilizamos o operador de cast (Vestuario) antes da variável lojaVestuario. 
Isso indica ao compilador que estamos convertendo explicitamente a referência para o tipo Vestuario. 
Em seguida, atribuímos essa referência convertida à variável vestuarioLoja, que é do tipo Vestuario.
 */


 /*
    Upcasting - Loja para Informatica
    O código cria uma nova instância da classe Informatica e a atribui a uma variável do tipo Loja, 
    demonstrando o upcasting. Em seguida, os dados do objeto lojaInformatica são impressos na tela.

    Loja lojaInformatica = new Informatica(220, 4500.0, 6, 1500);
    Criamos uma instância da classe Informatica e atribuindo uma variável do tipo Loja. 
    Isso é possível porque a classe Informatica é uma subclasse de Loja, o que significa 
    que um objeto da classe Informatica também é um objeto da classe Loja. 
    Portanto, podemos realizar essa atribuição de forma segura.

  */