class Loja {
    private int metrosQuadrados;
    private double valor;
    private int numeroLoja;

    public Loja(int metrosQuadrados, double valor, int numeroLoja) {
        this.metrosQuadrados = metrosQuadrados;
        this.valor = valor;
        this.numeroLoja = numeroLoja;
    }

    public int getMetrosQuadrados() {
        return metrosQuadrados;
    }

    public double getValor() {
        return valor;
    }

    public int getNumeroLoja() {
        return numeroLoja;
    }

    @Override
    public String toString() {
        return "Loja [metrosQuadrados=" + metrosQuadrados + ", valor=" + valor + ", numeroLoja=" + numeroLoja + "]";
    }
}

/*
 Criamos instâncias das classes Loja, Livraria, Informatica e Vestuario, preenchendo 
 seus respectivos atributos. Em seguida, imprimimos os dados utilizando o método toString().

Realizamos upcasting, onde uma instância da classe filha é atribuída a uma variável da classe pai (Loja). 
Por fim, fizemos downcasting, convertendo as instâncias da classe pai de volta para as classes filhas correspondentes.
 */
