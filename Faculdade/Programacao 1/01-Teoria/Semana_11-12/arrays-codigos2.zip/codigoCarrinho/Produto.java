public class Produto {
    private String nome;
    private double preco;

    /**
     * Construtor da classe Produto.
     *
     * @param nome  O nome do produto.
     * @param preco O preço do produto.
     */
    public Produto(String nome, double preco) {
        this.nome = nome;
        this.preco = preco;
    }

    /**
     * Obtém o nome do produto.
     *
     * @return O nome do produto.
     */
    public String getNome() {
        return nome;
    }

    /**
     * Define o nome do produto.
     *
     * @param nome O nome do produto a ser definido.
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * Obtém o preço do produto.
     *
     * @return O preço do produto.
     */
    public double getPreco() {
        return preco;
    }

    /**
     * Define o preço do produto.
     *
     * @param preco O preço do produto a ser definido.
     */
    public void setPreco(double preco) {
        this.preco = preco;
    }

    /**
     * Retorna uma representação em formato de string do objeto Produto,
     * exibindo o nome e o preço.
     *
     * @return Uma string que representa o objeto Produto.
     */
    @Override
    public String toString() {
        return "Nome: " + nome + ", Preço: " + preco;
    }
}