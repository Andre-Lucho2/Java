public class Carrinho {
    private static final int TAMANHO_MAXIMO = 100;
    private Produto[] produtos;
    private int tamanhoAtual;

    /**
     * Construtor da classe Carrinho.
     * Inicializa o array de produtos e define o tamanho atual como zero.
     */
    public Carrinho() {
        produtos = new Produto[TAMANHO_MAXIMO];
        tamanhoAtual = 0;
    }

    /**
     * Adiciona um produto ao carrinho.
     * Verifica se o carrinho está cheio antes de adicionar o produto.
     *
     * @param produto O produto a ser adicionado ao carrinho.
     */
    public void adicionarProduto(Produto produto) {
        if (tamanhoAtual < TAMANHO_MAXIMO) {
            produtos[tamanhoAtual] = produto;
            tamanhoAtual++;
            System.out.println("Produto adicionado ao carrinho.");
        } else {
            System.out.println("O carrinho está cheio. Não é possível adicionar mais produtos.");
        }
    }

    /**
     * Remove um produto do carrinho com base no índice.
     *
     * @param indice O índice do produto a ser removido.
     */
    public void removerProduto(int indice) {
        if (indice >= 0 && indice < tamanhoAtual) {
            for (int i = indice; i < tamanhoAtual - 1; i++) {
                produtos[i] = produtos[i + 1];
            }
            produtos[tamanhoAtual - 1] = null;
            tamanhoAtual--;
            System.out.println("Produto removido do carrinho.");
        } else {
            System.out.println("Índice inválido. Produto não encontrado no carrinho.");
        }
    }

    /**
     * Exibe o conteúdo atual do carrinho.
     * Percorre o array de produtos e exibe o nome e o preço de cada produto.
     */
    public void exibirCarrinho() {
        System.out.println("=== Carrinho de Compras ===");
        if (tamanhoAtual > 0) {
            for (int i = 0; i < tamanhoAtual; i++) {
                System.out.println("Produto " + i + ": " + produtos[i].getNome() + " - Preço: " + produtos[i].getPreco());
            }
        } else {
            System.out.println("O carrinho está vazio.");
        }
    }

    /**
     * Acessa um produto específico do carrinho com base no índice.
     *
     * @param indice O índice do produto a ser acessado.
     * @return O produto acessado, ou null se o índice for inválido.
     */
    public Produto acessarProduto(int indice) {
        if (indice >= 0 && indice < tamanhoAtual) {
            return produtos[indice];
        } else {
            System.out.println("Índice inválido. Produto não encontrado no carrinho.");
            return null;
        }
    }

    /**
     * Pesquisa um produto no carrinho com base no nome.
     * Compara o nome do produto com o nome fornecido (ignorando diferenças de caixa alta/baixa).
     * Exibe o nome e o preço do produto se encontrado.
     *
     * @param nome O nome do produto a ser pesquisado.
     */
    public void pesquisarProduto(String nome) {
        boolean encontrado = false;
        for (int i = 0; i < tamanhoAtual; i++) {
            //equalsIgnoreCase é um método da classe String em Java que verifica se duas strings são iguais, ignorando diferenças de caixa alta/baixa.
            if (produtos[i].getNome().equalsIgnoreCase(nome)) {
                System.out.println("Produto encontrado:");
                System.out.println("Nome: " + produtos[i].getNome());
                System.out.println("Preço: " + produtos[i].getPreco());
                encontrado = true;
            }
        }
        if (!encontrado) {
            System.out.println("Produto não encontrado no carrinho.");
        }
    }
}

