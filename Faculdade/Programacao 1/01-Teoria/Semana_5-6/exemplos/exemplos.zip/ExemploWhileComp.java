public class ExemploWhileComp {
    public static void main(String[] args) {
        int i = 1;
        while (i <= 10) {
            System.out.println(i);
            i++;
        }
        System.out.println("Laço while encerrado.");
    }
}